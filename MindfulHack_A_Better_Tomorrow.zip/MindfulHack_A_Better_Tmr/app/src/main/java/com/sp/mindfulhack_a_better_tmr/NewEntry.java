package com.sp.mindfulhack_a_better_tmr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NewEntry extends AppCompatActivity {
    private TextView dateTime;
    private EditText userThoughts;
    private Button saveBtn;
    private DatabaseHelper helper= null;
    private String ID ="";
    private RadioGroup userMood;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_entry);


        helper = new DatabaseHelper(this);
        userMood = findViewById(R.id.radioMood);
        userThoughts = findViewById(R.id.userThoughts);
        saveBtn = findViewById(R.id.saveEntry);
        dateTime = findViewById(R.id.dateTime);
        dateTime.setText(
                new SimpleDateFormat("EEEE, dd MMMM yyyy HH:mm a", Locale.getDefault())
                        .format(new Date())
        );

        saveBtn.setOnClickListener(onSave);
        ID = getIntent().getStringExtra("ID");
        if (ID != null) {
            load();
        }
    }
    private void load() {
        Cursor c = helper.getById(ID);
        c.moveToFirst();
        dateTime.setText(helper.getDateTime(c));
        userThoughts.setText(helper.getUserThoughts(c));
        if (helper.getUserMood(c).equals("Happy")) {
            userMood.check(R.id.radioHappy);
        } else if (helper.getUserMood(c).equals("Sad")) {
            userMood.check(R.id.radioSad);
        } else if (helper.getUserMood(c).equals("Angry")) {
            userMood.check(R.id.radioAngry);
        }
    }

    View.OnClickListener onSave = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            String dateStr = dateTime.getText().toString();
            String thoughtStr = userThoughts.getText().toString();
            String moodStr = "";
            switch (userMood.getCheckedRadioButtonId()) {
                case R.id.radioHappy:
                    moodStr = "Happy";
                    break;
                case R.id.radioSad:
                    moodStr = "Sad";
                    break;
                case R.id.radioAngry:
                    moodStr = "Angry";
                    break;

            }

            if (ID == null) {
                helper.insert(dateStr,thoughtStr,moodStr);
            } else {
                helper.update(ID,dateStr,thoughtStr,moodStr);
            }
            Toast.makeText(getApplicationContext(), "Saved!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getApplicationContext(),JournalActivity.class));
        }
    };
}