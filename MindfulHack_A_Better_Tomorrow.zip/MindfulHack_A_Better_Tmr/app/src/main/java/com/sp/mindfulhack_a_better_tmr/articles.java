package com.sp.mindfulhack_a_better_tmr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class articles extends AppCompatActivity {

    RecyclerView dataList;
    List<String> titles;
    List<Integer> images;
    Adapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_articles);

        //textView=findViewById(R.id.textView);
        dataList = findViewById(R.id.datalist);

        titles = new ArrayList<>();
        images = new ArrayList<>();

        titles.add("Building Better Mental Health");
        titles.add("Improving your Mental Health");
        titles.add("Importance of Mental Health");
        titles.add("Raise Awareness");


        images.add(R.drawable.pic1);
        images.add(R.drawable.pic2);
        images.add(R.drawable.pic3);
        images.add(R.drawable.pic4);



        adapter = new Adapter(this,titles,images);


        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false);
        dataList.setLayoutManager(gridLayoutManager);
        dataList.setAdapter(adapter);

        adapter.OnRecyclerClickListener(new Adapter.OnRecyclerClickListener() {
            @Override
            public void OnItemClick(int position) {
                if(position==0) {
                    Intent intent = new Intent(articles .this, aarticle.class);
                    startActivity(intent);
                }
                if(position==1) {
                    Intent intent = new Intent(articles .this, barticle.class);
                    startActivity(intent);
                }
                if(position==2) {
                    Intent intent = new Intent(articles .this, carticle.class);
                    startActivity(intent);
                }
                if(position==3) {
                    Intent intent = new Intent(articles .this, darticle.class);
                    startActivity(intent);
                }

            }
        });


    }
}