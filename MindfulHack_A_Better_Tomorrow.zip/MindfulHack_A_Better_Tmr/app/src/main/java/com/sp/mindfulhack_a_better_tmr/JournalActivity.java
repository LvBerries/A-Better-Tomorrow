package com.sp.mindfulhack_a_better_tmr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cursoradapter.widget.CursorAdapter;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class JournalActivity extends AppCompatActivity {
    private ImageView addEntry, journal_home;
    private Cursor model = null;
    private JournalAdapter adapter = null;
    private ListView list;
    DatabaseHelper helper = null;
    private TextView empty = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        addEntry = findViewById(R.id.addEntry);
        addEntry.setOnClickListener(AddEntry);
        journal_home = findViewById(R.id.journal_home);

        empty = findViewById(R.id.empty);
        helper = new DatabaseHelper(this); //returns cursor
        list = findViewById(R.id.journallist);
        model = helper.getAll(); //call getAll() to return Cursor
        adapter = new JournalAdapter(this, model, 0);
        list.setAdapter(adapter);
        list.setOnItemClickListener(onListClick);

        journal_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), CardView_Web.class));
            }
        });
    }
    private View.OnClickListener AddEntry = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent i = new Intent(getApplicationContext(), NewEntry.class);
            startActivity(i);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        if (model != null) {
            model.close();
        }
        model = helper.getAll(); //Reload the content of Cursor (record list)
        if (model.getCount() > 0) {
            empty.setVisibility(View.INVISIBLE);
        }
        adapter.swapCursor(model); //update List View with new record list
    }

    @Override
    protected void onDestroy() {
        helper.close();
        super.onDestroy();
    }

    private AdapterView.OnItemClickListener onListClick = new AdapterView.OnItemClickListener () {
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            model.moveToPosition(position);
            String recordID = helper.getID(model);
            Intent intent;
            intent = new Intent (JournalActivity.this, NewEntry.class);
            intent.putExtra("ID", recordID);
            startActivity(intent);
        }
    };


    static class Holder {
        private TextView userMood,datetime = null;
        private ImageView icon = null;



        Holder(View row) {
            datetime = row.findViewById(R.id.timedate);
            userMood = row.findViewById(R.id.listMood);
            icon = row.findViewById(R.id.moodImage);


        }


        void populateFrom(Cursor c, DatabaseHelper helper) {
            userMood.setText(helper.getUserMood(c));
            datetime.setText(helper.getDateTime(c));

            if (helper.getUserMood(c).equals("Happy")) {
                icon.setImageResource(R.drawable.green);
            } else if (helper.getUserMood(c).equals("Sad")) {
                icon.setImageResource(R.drawable.blue);
            } else {
                icon.setImageResource(R.drawable.red);
            }

        }
    }


    //CursorAdapter creates a View for each row in a Cursor whr each row correspond
    // to a record read from the table Model, uses newView() and bindView() methods
    class JournalAdapter extends CursorAdapter {
        JournalAdapter(Context context, Cursor cursor, int flags) {
            super(context, cursor, flags);

        }

        @Override
        //Cursor is a collection of records read from the table model
        public void bindView(View view, Context context, Cursor cursor) {
            Holder holder = (Holder) view.getTag();
            holder.populateFrom(cursor, helper);
        } //handles recycled row disappears from the UI View
        //method of CursorAdapter

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.row, parent, false);
            Holder holder = new Holder(row);
            row.setTag(holder);
            return (row);
        } //inflates new row in UI view
        //method of CursorAdapter
    }

}
