package com.sp.mindfulhack_a_better_tmr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "journal.db";
    private static final int SCHEMA_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, SCHEMA_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Will be called once when the database is not created
        db.execSQL("CREATE TABLE journal_table (_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "userThoughts TEXT,dateTime TEXT,userMood TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Will not be called until SCHEMA_VERSION increases
        //Here we cna upgrade the database e.g. add more tables
    }


    public Cursor getAll() {
        return (getReadableDatabase().rawQuery(
                "SELECT _id,userThoughts,dateTime,userMood FROM journal_table ORDER BY dateTime", null));
    }


    public Cursor getById(String id) {
        String[] args = {id};

        return (getReadableDatabase().rawQuery(
                "SELECT _id," +
                        "userThoughts,dateTime,userMood FROM journal_table WHERE _ID = ?", args));
    }


    public void insert(String userThoughts,String dateTime,String userMood) {
        ContentValues cv = new ContentValues();

        cv.put("dateTime", dateTime);
        cv.put("userThoughts",userThoughts);
        cv.put("userMood",userMood);


        getWritableDatabase().insert("journal_table", "dateTime", cv);
    }


    public void update (String id,String userThoughts, String dateTime,String userMood) {
        ContentValues cv = new ContentValues();
        String [] args = {id};
        cv.put("userThoughts",userThoughts);
        cv.put("dateTime", dateTime);
        cv.put("userMood",userMood);


        getWritableDatabase().update("journal_table", cv, "_ID = ?", args);
    }


    public String getID(Cursor c) { return (c.getString(0)); }


    public String getDateTime(Cursor c){return (c.getString(1));}


    public String getUserThoughts(Cursor c){return (c.getString(2));}

    public String getUserMood(Cursor c){return (c.getString(3));}


}